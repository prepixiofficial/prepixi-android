# PREPIXI CARDS — Roadmap

- [x] Replace the homepage placeholder with the reference-matched PREPIXI start screen.
- [x] Build the selectable class, exam, subject, and chapter flow with working back navigation.
- [x] Add ten static cards, sequence/random modes, progress, tap interactions, and the help guide.
- [x] Validate behavior and mobile/desktop presentation; run tests and check preview build logs.
- [x] Update selection wording and limit classes to 11 and 12 with JEE, NEET, and Boards streams.
- [x] Add stream-specific subjects with matching static flashcard decks and elevated stack-card browsing.
- [x] Show a completion card after the final next gesture and return to chapter selection with Done.
- [x] Remove the selection step counter and verify the updated flow, tests, and preview.
- [x] Add a Class 11 JEE Trigonometric Functions chapter using the uploaded formula sheets.
- [ ] Expand the trigonometry deck beyond ten cards, separating formulas from the uploaded sheets.
- [ ] Format formula answers for clear reading and center the homepage headline without periods.
- [ ] Verify the formula deck, homepage, tests, and mobile/desktop preview.