# PREPIXI CARDS

## What to build

- Replace the placeholder at `/` with a mobile-first homepage closely matching the supplied PREPIXI reference: centered branding, bold two-line headline, short supporting copy, layered flashcard artwork, black start button, and restrained monochrome details.
- Build the complete selection sequence: class, exam/board, subject, and chapter. Back controls return to the prior selection, and the chapter screen offers Sequence Wise and Random study modes.
- Create a study view with ten realistic static sample cards, progress, a centered chapter title, back and help controls, single-tap flip, and double-tap navigation on each half. Random mode reshuffles whenever it is selected.
- Keep the visual identity black, white, and grey; adapt the reference layout to desktop without changing its character. Do not add accounts, a backend, bottom navigation, or dashboards.

## Technical details

- Use the existing TanStack Start root page and client-side state for this single guided flow; keep the sample flashcard content in code.
- Use the uploaded transparent black/white logo artwork, vector card illustration, existing design-system tokens, and the existing UI controls.
- Add focused tests for shuffle behavior and verify the full study flow at mobile and desktop sizes.

## Validation

- Run the existing route test plus the new flashcard behavior tests.
- Walk through selection, study, flip, previous/next, help, and back navigation in the preview; inspect the mobile and desktop layouts and current build logs.