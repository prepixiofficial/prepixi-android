# Prepixicards

Build PREPIXI CARDS – Flashcard Learning Website

Build a fully functional, responsive, mobile-first flashcard website named PREPIXI CARDS.

Design & Branding

Use my provided homepage UI image as the primary design reference. Closely follow its layout, spacing, typography, monochrome colours, floating flashcard illustration and overall premium aesthetic.

Use my other uploaded image as the official PREPIXI logo.

Maintain a premium black, white and grey visual identity throughout every page.

Design mobile screens first, then adapt them for desktop.

Website Flow

Homepage → Class Selection → Exam/Board Selection → Subject Selection → Chapter Selection → Flashcards.

Flashcard Features

Provide two study modes: Sequence Wise and Random.

Shuffle cards every time Random mode is selected.

Single tap flips a card to reveal its answer.

Double-tap the right half to go to the next card.

Double-tap the left half to go to the previous card.

Display study progress at the top.

Flashcard header: Back button (left), Chapter name (centre), Help (?) button (right).

Help guide must explain card flipping, double-tap navigation and returning to chapters.

Back buttons must return to the previous selection screen.

Content & Technical Requirements

Include 10 realistic sample flashcards with questions and answers.

Don't use standard emoji. Use vector or svg or other.

Use predefined static flashcard data stored directly in the code.

No database or backend required.

Make all navigation and interactions functional.

Strictly Exclude

No login or signup.

No user profiles.

No bottom navigation.

No progress dashboard.

Important: Prioritize accurate implementation of the supplied UI reference and all specified interactions. Do not independently redesign the selected homepage or add features that were not requested. Build a polished, production-quality experience.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://prepixicards.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4701d6f8-adf3-4ea2-b58b-31d81e38bf7c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
