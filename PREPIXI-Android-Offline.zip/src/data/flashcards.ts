export const CLASSES = ["Class 11", "Class 12"] as const;
export type ClassName = (typeof CLASSES)[number];

export const EXAMS = [
  "Joint Entrance Examination (JEE)",
  "National Eligibility cum Entrance Test (NEET)",
  "State Board Examinations (Boards)",
] as const;

export const SUBJECTS = ["Physics", "Chemistry", "Mathematics", "Biology"] as const;

export type Subject = (typeof SUBJECTS)[number];
export type Exam = (typeof EXAMS)[number];
export type ExamStream = "PCM" | "PCB" | "PCMB";

export const EXAM_DETAILS: Record<Exam, { stream: ExamStream; subjects: Subject[] }> = {
  "Joint Entrance Examination (JEE)": {
    stream: "PCM",
    subjects: ["Physics", "Chemistry", "Mathematics"],
  },
  "National Eligibility cum Entrance Test (NEET)": {
    stream: "PCB",
    subjects: ["Physics", "Chemistry", "Biology"],
  },
  "State Board Examinations (Boards)": {
    stream: "PCMB",
    subjects: ["Physics", "Chemistry", "Mathematics", "Biology"],
  },
};

export type Flashcard = {
  question: string;
  answer: string;
  topic?: string;
  format?: "formula";
};

export type ChapterDeck = {
  name: string;
  cards: Flashcard[];
  availableFor?: { className: ClassName; exam: Exam };
};

export const CHAPTER_BY_SUBJECT: Record<Subject, string> = {
  Physics: "Units and Measurements",
  Chemistry: "Structure of Atom",
  Mathematics: "Quadratic Equations",
  Biology: "Life Processes",
};

const EXISTING_FLASHCARDS_BY_SUBJECT = {
  Science: [
    {
      question: "What is photosynthesis?",
      answer:
        "Photosynthesis is the process by which green plants use sunlight, carbon dioxide, and water to make glucose and release oxygen.",
    },
    {
      question: "Why are stomata important to a plant?",
      answer:
        "Stomata allow carbon dioxide and oxygen to move in and out of leaves. Their guard cells open and close the pores and help regulate water loss.",
    },
    {
      question: "What role does chlorophyll play in photosynthesis?",
      answer:
        "Chlorophyll is the green pigment in chloroplasts. It absorbs light energy that powers the reactions of photosynthesis.",
    },
    {
      question: "Write the balanced equation for aerobic respiration.",
      answer:
        "C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energy. Cells release usable energy from glucose in the presence of oxygen.",
    },
    {
      question: "How are alveoli adapted for gas exchange?",
      answer:
        "Alveoli provide a large, moist surface with thin walls and a rich blood supply, allowing oxygen and carbon dioxide to diffuse quickly.",
    },
    {
      question: "Which blood component carries most oxygen?",
      answer:
        "Haemoglobin in red blood cells binds oxygen in the lungs and carries it to body tissues.",
    },
    {
      question: "What is double circulation in humans?",
      answer:
        "In one complete circuit, blood passes through the heart twice: once between the heart and lungs, and once between the heart and the body.",
    },
    {
      question: "What does xylem transport in a plant?",
      answer:
        "Xylem carries water and dissolved minerals from the roots toward the stems and leaves.",
    },
    {
      question: "What is a nephron?",
      answer:
        "A nephron is the kidney’s structural and functional unit. It filters blood and helps form urine while returning useful substances to the blood.",
    },
    {
      question: "What is transpiration, and why does it help plants?",
      answer:
        "Transpiration is the loss of water vapour, mainly through leaf stomata. It helps cool the plant and draws water upward through the xylem.",
    },
  ],
  Mathematics: [
    {
      question: "What is the standard form of a quadratic equation?",
      answer:
        "A quadratic equation is written ax² + bx + c = 0, where a, b, and c are constants and a ≠ 0.",
    },
    {
      question: "What is the discriminant of ax² + bx + c = 0?",
      answer:
        "The discriminant is D = b² − 4ac. It indicates the nature of the equation’s roots.",
    },
    {
      question: "When does a quadratic have two equal real roots?",
      answer:
        "A quadratic has two equal real roots when its discriminant is zero: b² − 4ac = 0.",
    },
    {
      question: "State the quadratic formula.",
      answer:
        "For ax² + bx + c = 0, the roots are x = (−b ± √(b² − 4ac)) / 2a.",
    },
    {
      question: "What is the sum of the roots of ax² + bx + c = 0?",
      answer:
        "If the roots are α and β, their sum is α + β = −b/a.",
    },
    {
      question: "What is the product of the roots of ax² + bx + c = 0?",
      answer:
        "If the roots are α and β, their product is αβ = c/a.",
    },
    {
      question: "Find the roots of x² − 5x + 6 = 0.",
      answer:
        "Factor the expression as (x − 2)(x − 3) = 0. The roots are x = 2 and x = 3.",
    },
    {
      question: "How can the graph of a quadratic reveal its roots?",
      answer:
        "The roots are the x-coordinates where the parabola intersects or touches the x-axis.",
    },
    {
      question: "What is the axis of symmetry of y = ax² + bx + c?",
      answer:
        "The axis of symmetry is the vertical line x = −b/(2a), passing through the vertex of the parabola.",
    },
    {
      question: "How can you solve a quadratic by factorisation?",
      answer:
        "Write the quadratic as a product of two linear factors, set each factor equal to zero, and solve the resulting equations.",
    },
  ],
  "Social Science": [
    {
      question: "What was the Rowlatt Act of 1919?",
      answer:
        "It allowed the colonial government to imprison people without trial. Indians opposed it as a serious restriction on civil liberties.",
    },
    {
      question: "What happened at Jallianwala Bagh?",
      answer:
        "On 13 April 1919, troops under General Dyer fired on a large, unarmed gathering in Amritsar, killing and injuring many people.",
    },
    {
      question: "When did the Non-Cooperation Movement begin?",
      answer:
        "The Indian National Congress adopted the programme in 1920. It called for peaceful non-cooperation with colonial institutions.",
    },
    {
      question: "Why did Gandhi withdraw the Non-Cooperation Movement?",
      answer:
        "After violence at Chauri Chaura in February 1922, Gandhi called off the movement because he believed people were not yet prepared for non-violence.",
    },
    {
      question: "Why was the Simon Commission widely boycotted?",
      answer:
        "The 1928 commission had no Indian members, even though it was sent to recommend constitutional reforms for India.",
    },
    {
      question: "What did Purna Swaraj mean?",
      answer:
        "Purna Swaraj means complete independence. The Congress declared it as its goal at the Lahore session in December 1929.",
    },
    {
      question: "What was the purpose of Gandhi’s Salt March?",
      answer:
        "In 1930 Gandhi marched from Sabarmati to Dandi and made salt in defiance of the British salt law, beginning the Civil Disobedience Movement.",
    },
    {
      question: "What did the Gandhi-Irwin Pact of 1931 agree to?",
      answer:
        "The pact paused the Civil Disobedience Movement. The Congress agreed to attend the Second Round Table Conference in London.",
    },
    {
      question: "When was the Quit India resolution adopted?",
      answer:
        "The Congress adopted the Quit India resolution in Bombay on 8 August 1942. Gandhi called on people to ‘Do or Die.’",
    },
    {
      question: "Who led the Indian National Army during the 1940s?",
      answer:
        "Subhas Chandra Bose became its prominent leader and reorganised the Indian National Army during the Second World War.",
    },
  ],
  English: [
    {
      question: "Which verb agrees with ‘Neither of the answers’?",
      answer:
        "Use a singular verb: ‘Neither of the answers is correct.’ Neither is treated as singular in this construction.",
    },
    {
      question: "Change ‘They completed the project’ to the passive voice.",
      answer:
        "‘The project was completed by them.’ The object becomes the subject, and the verb takes a passive form.",
    },
    {
      question: "Change ‘She said, “I am tired”’ to reported speech.",
      answer:
        "‘She said that she was tired.’ The pronoun and tense shift to match the reporting context.",
    },
    {
      question: "When should you use ‘who’ rather than ‘which’ in a relative clause?",
      answer:
        "Use who for people: ‘The student who won the prize thanked her teacher.’ Use which for things and animals.",
    },
    {
      question: "What is a gerund?",
      answer:
        "A gerund is an -ing verb form used as a noun, as in ‘Reading improves concentration.’",
    },
    {
      question: "What verb form follows ‘would’ in a second conditional?",
      answer:
        "Use the base form: ‘If I had more time, I would learn another language.’ The if-clause uses the past simple.",
    },
    {
      question: "When do you use the present perfect instead of the simple past?",
      answer:
        "Use the present perfect for a past action connected to the present when no finished time is specified: ‘I have finished my work.’",
    },
    {
      question: "What is the difference between an adjective and an adverb?",
      answer:
        "An adjective describes a noun or pronoun; an adverb commonly describes a verb, adjective, or another adverb.",
    },
    {
      question: "Where does a comma usually go after an introductory phrase?",
      answer:
        "Place a comma after the introductory phrase: ‘After the rain stopped, we continued the match.’",
    },
    {
      question: "When should you use ‘fewer’ rather than ‘less’?",
      answer:
        "Use fewer with countable plural nouns, such as ‘fewer books.’ Use less with amounts that are not usually counted, such as ‘less water.’",
    },
  ],
};

const PHYSICS_FLASHCARDS: Flashcard[] = [
  { question: "What is the SI unit of force?", answer: "The newton (N), equal to one kilogram metre per second squared (kg·m/s²)." },
  { question: "What are the dimensions of velocity?", answer: "Velocity has dimensions [L T⁻¹]: length divided by time." },
  { question: "How many significant figures are in 2.050?", answer: "There are four significant figures. Zeros between digits and the final decimal zero are significant." },
  { question: "What is the difference between accuracy and precision?", answer: "Accuracy is closeness to the true value; precision is how closely repeated measurements agree with one another." },
  { question: "Convert 72 km/h to metres per second.", answer: "Multiply by 5/18: 72 × 5/18 = 20 m/s." },
  { question: "Why is the equation v = u + at dimensionally consistent?", answer: "Both velocity terms have dimensions [L T⁻¹], and acceleration × time has [L T⁻²][T] = [L T⁻¹]." },
  { question: "What does the least count of an instrument mean?", answer: "It is the smallest measurement an instrument can reliably resolve." },
  { question: "What is one difference between a scalar and a vector?", answer: "A scalar has magnitude only; a vector has both magnitude and direction." },
  { question: "How do absolute errors combine when measured quantities are added?", answer: "The maximum absolute errors add: Δ(A + B) = ΔA + ΔB." },
  { question: "What are the dimensions of the gravitational constant G?", answer: "From F = Gm₁m₂/r², [G] = [M⁻¹ L³ T⁻²]." },
];

const CHEMISTRY_FLASHCARDS: Flashcard[] = [
  { question: "What does the atomic number of an element represent?", answer: "The atomic number is the number of protons in the nucleus of each atom of that element." },
  { question: "How is the mass number of an atom calculated?", answer: "Mass number = number of protons + number of neutrons in the nucleus." },
  { question: "What are isotopes?", answer: "Isotopes are atoms of the same element with the same number of protons but different numbers of neutrons." },
  { question: "What is the relative charge of an electron?", answer: "An electron has a relative charge of −1 and a charge of approximately −1.602 × 10⁻¹⁹ coulombs." },
  { question: "What did Rutherford’s gold-foil experiment reveal?", answer: "It showed that an atom is mostly empty space, with positive charge and most of its mass concentrated in a small nucleus." },
  { question: "What did Bohr propose about electron energies?", answer: "Electrons occupy specific, quantised energy levels around the nucleus and can move between them by absorbing or emitting energy." },
  { question: "How many electrons can the nth shell hold at most?", answer: "The maximum is 2n² electrons, where n is the shell number." },
  { question: "What is the energy of a photon with frequency ν?", answer: "Photon energy is E = hν, where h is Planck’s constant." },
  { question: "Why are carbon-12 and carbon-14 isotopes?", answer: "Both have six protons, but carbon-12 has six neutrons and carbon-14 has eight." },
  { question: "What is the shell electron configuration of sodium?", answer: "Sodium has 11 electrons arranged 2, 8, 1 across its first three shells." },
];

const formulaCard = (topic: string, question: string, answer: string): Flashcard => ({
  topic,
  question,
  answer,
  format: "formula",
});

const TRIGONOMETRIC_FUNCTIONS_FLASHCARDS: Flashcard[] = [
  formulaCard("Trigonometric ratios", "How is sine defined in a right triangle?", "sin θ = P / H"),
  formulaCard("Trigonometric ratios", "How is cosine defined in a right triangle?", "cos θ = B / H"),
  formulaCard("Trigonometric ratios", "How is tangent defined in a right triangle?", "tan θ = P / B"),
  formulaCard("Trigonometric ratios", "How is cosecant defined in a right triangle?", "cosec θ = H / P"),
  formulaCard("Trigonometric ratios", "How is secant defined in a right triangle?", "sec θ = H / B"),
  formulaCard("Trigonometric ratios", "How is cotangent defined in a right triangle?", "cot θ = B / P"),
  formulaCard("Quotient identities", "How can tangent be written using sine and cosine?", "tan θ = sin θ / cos θ"),
  formulaCard("Quotient identities", "How can cotangent be written using sine and cosine?", "cot θ = cos θ / sin θ"),
  formulaCard("Reciprocal identities", "What is secant as the reciprocal of cosine?", "sec θ = 1 / cos θ"),
  formulaCard("Reciprocal identities", "What is cosecant as the reciprocal of sine?", "cosec θ = 1 / sin θ"),
  formulaCard("Reciprocal identities", "What is cotangent as the reciprocal of tangent?", "cot θ = 1 / tan θ"),
  formulaCard("Fundamental identities", "State the Pythagorean identity for sine and cosine.", "sin² θ + cos² θ = 1"),
  formulaCard("Fundamental identities", "State the Pythagorean identity for secant and tangent.", "sec² θ − tan² θ = 1"),
  formulaCard("Fundamental identities", "Factor the secant–tangent identity.", "(sec θ − tan θ)(sec θ + tan θ) = 1"),
  formulaCard("Fundamental identities", "State the Pythagorean identity for cosecant and cotangent.", "cosec² θ − cot² θ = 1"),
  formulaCard("Fundamental identities", "Factor the cosecant–cotangent identity.", "(cosec θ − cot θ)(cosec θ + cot θ) = 1"),
  formulaCard("Fundamental identities", "Simplify sin⁴ θ + cos⁴ θ.", "sin⁴ θ + cos⁴ θ = 1 − 2sin² θ cos² θ"),
  formulaCard("Fundamental identities", "Simplify sin⁶ θ + cos⁶ θ.", "sin⁶ θ + cos⁶ θ = 1 − 3sin² θ cos² θ"),

  ...[
    ["sin", "0°", "0"], ["sin", "30°", "1/2"], ["sin", "45°", "1/√2"],
    ["sin", "60°", "√3/2"], ["sin", "90°", "1"],
    ["cos", "0°", "1"], ["cos", "30°", "√3/2"], ["cos", "45°", "1/√2"],
    ["cos", "60°", "1/2"], ["cos", "90°", "0"],
    ["tan", "0°", "0"], ["tan", "30°", "1/√3"], ["tan", "45°", "1"],
    ["tan", "60°", "√3"], ["tan", "90°", "undefined"],
    ["cot", "0°", "undefined"], ["cot", "30°", "√3"], ["cot", "45°", "1"],
    ["cot", "60°", "1/√3"], ["cot", "90°", "0"],
    ["sec", "0°", "1"], ["sec", "30°", "2/√3"], ["sec", "45°", "√2"],
    ["sec", "60°", "2"], ["sec", "90°", "undefined"],
    ["cosec", "0°", "undefined"], ["cosec", "30°", "2"], ["cosec", "45°", "√2"],
    ["cosec", "60°", "2/√3"], ["cosec", "90°", "1"],
  ].map(([ratio, angle, value]) =>
    formulaCard("Standard angle values", `What is ${ratio} ${angle}?`, `${ratio} ${angle} = ${value}`),
  ),

  formulaCard("Degree and radian conversion", "How many radians are in 180 degrees?", "180° = π radians"),
  formulaCard("Degree and radian conversion", "How do you convert degrees to radians?", "Radians = degrees × π / 180"),
  formulaCard("Degree and radian conversion", "How do you convert radians to degrees?", "Degrees = radians × 180 / π"),
  formulaCard("Common angle conversions", "Convert 30 degrees to radians.", "30° = π / 6"),
  formulaCard("Common angle conversions", "Convert 45 degrees to radians.", "45° = π / 4"),
  formulaCard("Common angle conversions", "Convert 60 degrees to radians.", "60° = π / 3"),
  formulaCard("Common angle conversions", "Convert 90 degrees to radians.", "90° = π / 2"),
  formulaCard("Common angle conversions", "Convert 180 degrees to radians.", "180° = π"),

  { topic: "Quadrants and signs", question: "Which trigonometric ratios are positive in quadrant I?", answer: "All six ratios are positive." },
  { topic: "Quadrants and signs", question: "Which trigonometric ratios are positive in quadrant II?", answer: "Sine and cosecant are positive." },
  { topic: "Quadrants and signs", question: "Which trigonometric ratios are positive in quadrant III?", answer: "Tangent and cotangent are positive." },
  { topic: "Quadrants and signs", question: "Which trigonometric ratios are positive in quadrant IV?", answer: "Cosine and secant are positive." },
  { topic: "Quadrants and signs", question: "Which direction is positive, and which is negative, around the unit circle?", answer: "Positive angles are anticlockwise; negative angles are clockwise." },

  formulaCard("Negative angles", "What is sin(−θ)?", "sin(−θ) = −sin θ"),
  formulaCard("Negative angles", "What is cos(−θ)?", "cos(−θ) = cos θ"),
  formulaCard("Negative angles", "What is tan(−θ)?", "tan(−θ) = −tan θ"),
  formulaCard("Negative angles", "What is cot(−θ)?", "cot(−θ) = −cot θ"),
  formulaCard("Negative angles", "What is sec(−θ)?", "sec(−θ) = sec θ"),
  formulaCard("Negative angles", "What is cosec(−θ)?", "cosec(−θ) = −cosec θ"),
  formulaCard("Periodicity", "What is the period of sine?", "sin(θ + 2nπ) = sin θ"),
  formulaCard("Periodicity", "What is the period of cosine?", "cos(θ + 2nπ) = cos θ"),
  formulaCard("Periodicity", "What is the period of tangent?", "tan(θ + nπ) = tan θ"),
  formulaCard("Periodicity", "What is the period of cotangent?", "cot(θ + nπ) = cot θ"),
  formulaCard("Periodicity", "What is the period of secant?", "sec(θ + 2nπ) = sec θ"),
  formulaCard("Periodicity", "What is the period of cosecant?", "cosec(θ + 2nπ) = cosec θ"),

  ...[
    ["sin", "−", "cos θ"], ["sin", "+", "cos θ"],
    ["cos", "−", "sin θ"], ["cos", "+", "−sin θ"],
    ["tan", "−", "cot θ"], ["tan", "+", "−cot θ"],
    ["cot", "−", "tan θ"], ["cot", "+", "−tan θ"],
    ["sec", "−", "cosec θ"], ["sec", "+", "−cosec θ"],
    ["cosec", "−", "sec θ"], ["cosec", "+", "−sec θ"],
  ].map(([ratio, sign, value]) =>
    formulaCard("Reduction formulas · π/2 ± θ", `Simplify ${ratio}(π/2 ${sign} θ).`, `${ratio}(π/2 ${sign} θ) = ${value}`),
  ),
  ...[
    ["sin", "−", "sin θ"], ["sin", "+", "−sin θ"],
    ["cos", "−", "−cos θ"], ["cos", "+", "−cos θ"],
    ["tan", "−", "−tan θ"], ["tan", "+", "tan θ"],
    ["cot", "−", "−cot θ"], ["cot", "+", "cot θ"],
    ["sec", "−", "−sec θ"], ["sec", "+", "−sec θ"],
    ["cosec", "−", "cosec θ"], ["cosec", "+", "−cosec θ"],
  ].map(([ratio, sign, value]) =>
    formulaCard("Reduction formulas · π ± θ", `Simplify ${ratio}(π ${sign} θ).`, `${ratio}(π ${sign} θ) = ${value}`),
  ),
  { topic: "Quick reduction rule", question: "What happens to the function name for an odd multiple of π/2?", answer: "It changes to its co-function." },
  { topic: "Quick reduction rule", question: "What happens to the function name for an even multiple of π/2?", answer: "It stays the same; determine the sign from the resulting quadrant." },

  formulaCard("Compound angles · sine", "State the sine addition formula.", "sin(A + B) = sin A cos B + cos A sin B"),
  formulaCard("Compound angles · sine", "State the sine subtraction formula.", "sin(A − B) = sin A cos B − cos A sin B"),
  formulaCard("Compound angles · cosine", "State the cosine addition formula.", "cos(A + B) = cos A cos B − sin A sin B"),
  formulaCard("Compound angles · cosine", "State the cosine subtraction formula.", "cos(A − B) = cos A cos B + sin A sin B"),
  formulaCard("Compound angles · tangent", "State the tangent addition formula.", "tan(A + B) = (tan A + tan B) / (1 − tan A tan B)"),
  formulaCard("Compound angles · tangent", "State the tangent subtraction formula.", "tan(A − B) = (tan A − tan B) / (1 + tan A tan B)"),
  formulaCard("Compound angles · cotangent", "State the cotangent addition formula.", "cot(A + B) = (cot A cot B − 1) / (cot A + cot B)"),
  formulaCard("Compound angles · cotangent", "State the cotangent subtraction formula.", "cot(A − B) = (cot A cot B + 1) / (cot B − cot A)"),
  formulaCard("Useful π/4 formulas", "Simplify tan(π/4 + θ).", "tan(π/4 + θ) = (1 + tan θ) / (1 − tan θ)"),
  formulaCard("Useful π/4 formulas", "Simplify tan(π/4 − θ).", "tan(π/4 − θ) = (1 − tan θ) / (1 + tan θ)"),
  formulaCard("Useful π/4 formulas", "If A + B = π/4, what identity connects tan A and tan B?", "(1 + tan A)(1 + tan B) = 2"),
  formulaCard("Three-angle tangent", "State the tangent formula for A + B + C.", "tan(A + B + C) = (tan A + tan B + tan C − tan A tan B tan C) / (1 − tan A tan B − tan B tan C − tan C tan A)"),
  formulaCard("Three-angle tangent", "If A + B + C = π, what identity connects their tangents?", "tan A + tan B + tan C = tan A tan B tan C"),

  formulaCard("Sum to product", "Convert sin C + sin D to a product.", "sin C + sin D = 2sin((C + D)/2) cos((C − D)/2)"),
  formulaCard("Sum to product", "Convert sin C − sin D to a product.", "sin C − sin D = 2sin((C − D)/2) cos((C + D)/2)"),
  formulaCard("Sum to product", "Convert cos C + cos D to a product.", "cos C + cos D = 2cos((C + D)/2) cos((C − D)/2)"),
  formulaCard("Sum to product", "Convert cos C − cos D to a product.", "cos C − cos D = −2sin((C + D)/2) sin((C − D)/2)"),
  formulaCard("Product to sum", "Convert 2sin A cos B to a sum.", "2sin A cos B = sin(A + B) + sin(A − B)"),
  formulaCard("Product to sum", "Convert 2cos A sin B to a difference.", "2cos A sin B = sin(A + B) − sin(A − B)"),
  formulaCard("Product to sum", "Convert 2cos A cos B to a sum.", "2cos A cos B = cos(A + B) + cos(A − B)"),
  formulaCard("Product to sum", "Convert 2sin A sin B to a difference.", "2sin A sin B = cos(A − B) − cos(A + B)"),

  formulaCard("Double angles", "State the sine double-angle formula.", "sin 2θ = 2sin θ cos θ"),
  formulaCard("Double angles", "Write cos 2θ as a difference of squares.", "cos 2θ = cos² θ − sin² θ"),
  formulaCard("Double angles", "Write cos 2θ using sin² θ.", "cos 2θ = 1 − 2sin² θ"),
  formulaCard("Double angles", "Write cos 2θ using cos² θ.", "cos 2θ = 2cos² θ − 1"),
  formulaCard("Double angles", "State the tangent double-angle formula.", "tan 2θ = 2tan θ / (1 − tan² θ)"),
  formulaCard("Double angles", "Express tan² θ using cos 2θ.", "tan² θ = (1 − cos 2θ) / (1 + cos 2θ)"),
  formulaCard("Double angles", "Express sin² θ using cos 2θ.", "sin² θ = (1 − cos 2θ) / 2"),
  formulaCard("Double angles", "Express cos² θ using cos 2θ.", "cos² θ = (1 + cos 2θ) / 2"),
  formulaCard("Triple angles", "State the sine triple-angle formula.", "sin 3θ = 3sin θ − 4sin³ θ"),
  formulaCard("Triple angles", "State the cosine triple-angle formula.", "cos 3θ = 4cos³ θ − 3cos θ"),
  formulaCard("Triple angles", "State the tangent triple-angle formula.", "tan 3θ = (3tan θ − tan³ θ) / (1 − 3tan² θ)"),
  formulaCard("Square-root shortcuts", "Simplify (sin θ + cos θ)².", "(sin θ + cos θ)² = 1 + sin 2θ"),
  formulaCard("Square-root shortcuts", "Simplify (sin θ − cos θ)².", "(sin θ − cos θ)² = 1 − sin 2θ"),
  formulaCard("Square-root shortcuts", "Express (sin θ + cos θ)² − 1 using sin 2θ.", "(sin θ + cos θ)² − 1 = sin 2θ"),

  formulaCard("Special angles", "Evaluate sin 15°.", "sin 15° = (√3 − 1) / (2√2)"),
  formulaCard("Special angles", "Evaluate cos 75°.", "cos 75° = (√3 − 1) / (2√2)"),
  formulaCard("Special angles", "Evaluate sin 75°.", "sin 75° = (√3 + 1) / (2√2)"),
  formulaCard("Special angles", "Evaluate cos 15°.", "cos 15° = (√3 + 1) / (2√2)"),
  formulaCard("Special angles", "Evaluate tan 15°.", "tan 15° = 2 − √3"),
  formulaCard("Special angles", "Evaluate cot 75°.", "cot 75° = 2 − √3"),
  formulaCard("Special angles", "Evaluate tan 75°.", "tan 75° = 2 + √3"),
  formulaCard("Special angles", "Evaluate cot 15°.", "cot 15° = 2 + √3"),
  formulaCard("Special angles", "Evaluate sin 18°.", "sin 18° = (√5 − 1) / 4"),
  formulaCard("Special angles", "Evaluate sin 54°.", "sin 54° = (√5 + 1) / 4"),
  formulaCard("Special angles", "Evaluate sin 36°.", "sin 36° = √(10 − 2√5) / 4"),
  formulaCard("Special angles", "Evaluate sin 72°.", "sin 72° = √(10 + 2√5) / 4"),
  formulaCard("Special angles", "Evaluate tan(π/8).", "tan(π/8) = √2 − 1"),
  formulaCard("Special angles", "Evaluate tan(3π/8).", "tan(3π/8) = √2 + 1"),

  formulaCard("Conditional identities · A + B + C = π", "If A + B + C = π, simplify sin 2A + sin 2B + sin 2C.", "sin 2A + sin 2B + sin 2C = 4sin A sin B sin C"),
  formulaCard("Conditional identities · A + B + C = π", "If A + B + C = π, simplify cos 2A + cos 2B + cos 2C.", "cos 2A + cos 2B + cos 2C = −1 − 4cos A cos B cos C"),
  formulaCard("Conditional identities · A + B + C = π", "If A + B + C = π, simplify sin A + sin B + sin C.", "sin A + sin B + sin C = 4cos(A/2) cos(B/2) cos(C/2)"),
  formulaCard("Conditional identities · A + B + C = π", "If A + B + C = π, simplify cos A + cos B + cos C.", "cos A + cos B + cos C = 1 + 4sin(A/2) sin(B/2) sin(C/2)"),
  formulaCard("Conditional identities · A + B + C = π", "If A + B + C = π, what is tan A + tan B + tan C?", "tan A + tan B + tan C = tan A tan B tan C"),
  formulaCard("Conditional identities · A + B + C = π", "If A + B + C = π, simplify cot A cot B + cot B cot C + cot C cot A.", "cot A cot B + cot B cot C + cot C cot A = 1"),
  formulaCard("Useful product results", "Simplify sin(A + B) sin(A − B).", "sin(A + B) sin(A − B) = sin² A − sin² B"),
  formulaCard("Useful product results", "Simplify cos(A + B) cos(A − B).", "cos(A + B) cos(A − B) = cos² A − sin² B"),
  formulaCard("Useful product results", "Simplify sin θ sin(60° + θ) sin(60° − θ).", "sin θ sin(60° + θ) sin(60° − θ) = (1/4)sin 3θ"),
  formulaCard("Useful product results", "Simplify cos θ cos(60° + θ) cos(60° − θ).", "cos θ cos(60° + θ) cos(60° − θ) = (1/4)cos 3θ"),
  formulaCard("Useful product results", "Simplify tan θ tan(60° + θ) tan(60° − θ).", "tan θ tan(60° + θ) tan(60° − θ) = tan 3θ"),
  formulaCard("Useful product results", "Evaluate the product cos θ cos 2θ cos 4θ … cos(2ⁿ⁻¹ θ).", "cos θ cos 2θ cos 4θ … cos(2ⁿ⁻¹ θ) = sin(2ⁿ θ) / (2ⁿ sin θ)"),
  formulaCard("Useful identities", "Simplify cot θ − tan θ.", "cot θ − tan θ = 2cot 2θ"),
  formulaCard("Useful identities", "Simplify cot(θ/2) − cot θ.", "cot(θ/2) − cot θ = cosec θ"),

  formulaCard("Trigonometric series", "Write the sine series for n angles in arithmetic progression.", "S = sin α + sin(α + β) + … + sin(α + (n − 1)β)"),
  formulaCard("Trigonometric series", "Find the sum of sines at angles in arithmetic progression.", "S = sin(nβ/2) sin(α + (n − 1)β/2) / sin(β/2)"),
  formulaCard("Trigonometric series", "Write the cosine series for n angles in arithmetic progression.", "C = cos α + cos(α + β) + … + cos(α + (n − 1)β)"),
  formulaCard("Trigonometric series", "Find the sum of cosines at angles in arithmetic progression.", "C = sin(nβ/2) cos(α + (n − 1)β/2) / sin(β/2)"),
  formulaCard("Splitting product denominators", "Rewrite 1 / (sin A sin B) as a difference.", "1 / (sin A sin B) = (cot A − cot B) / sin(B − A)"),
  formulaCard("Splitting product denominators", "Rewrite 1 / (cos A cos B) as a difference.", "1 / (cos A cos B) = (tan B − tan A) / sin(B − A)"),
  formulaCard("Telescoping cotangent", "Evaluate the telescoping cotangent sum from r = 1 to n.", "Σ[cot(θ + (r − 1)δ) − cot(θ + rδ)] = cot θ − cot(θ + nδ)"),

  ...[
    ["sin", "Domain", "ℝ"], ["sin", "Range", "[−1, 1]"], ["sin", "Period", "2π"],
    ["cos", "Domain", "ℝ"], ["cos", "Range", "[−1, 1]"], ["cos", "Period", "2π"],
    ["tan", "Domain", "ℝ except x = π/2 + nπ"], ["tan", "Range", "ℝ"], ["tan", "Period", "π"],
    ["cot", "Domain", "ℝ except x = nπ"], ["cot", "Range", "ℝ"], ["cot", "Period", "π"],
    ["sec", "Domain", "ℝ except x = π/2 + nπ"], ["sec", "Range", "(−∞, −1] ∪ [1, ∞)"], ["sec", "Period", "2π"],
    ["cosec", "Domain", "ℝ except x = nπ"], ["cosec", "Range", "(−∞, −1] ∪ [1, ∞)"], ["cosec", "Period", "2π"],
  ].map(([ratio, property, value]) =>
    formulaCard("Domain, range and period", `What is the ${property.toLowerCase()} of ${ratio} x?`, `${ratio} x · ${property} = ${value}`),
  ),
  formulaCard("Graph landmarks", "Where are the zeros of y = sin x?", "x = nπ"),
  formulaCard("Graph landmarks", "Where does y = sin x reach its maximum?", "x = π/2 + 2nπ; y = 1"),
  formulaCard("Graph landmarks", "Where does y = sin x reach its minimum?", "x = 3π/2 + 2nπ; y = −1"),
  formulaCard("Graph landmarks", "Where are the zeros of y = cos x?", "x = π/2 + nπ"),
  formulaCard("Graph landmarks", "Where does y = cos x reach its maximum?", "x = 2nπ; y = 1"),
  formulaCard("Graph landmarks", "Where does y = cos x reach its minimum?", "x = (2n + 1)π; y = −1"),
  formulaCard("Graph landmarks", "Where are the zeros of y = tan x?", "x = nπ"),
  formulaCard("Graph landmarks", "Where are the vertical asymptotes of y = tan x?", "x = π/2 + nπ"),
  formulaCard("Graph landmarks", "Where are the zeros of y = cot x?", "x = π/2 + nπ"),
  formulaCard("Graph landmarks", "Where are the vertical asymptotes of y = cot x?", "x = nπ"),
  formulaCard("Graph landmarks", "How are secant and cosecant related to cosine and sine?", "sec x = 1/cos x; cosec x = 1/sin x"),
  formulaCard("Range transformations", "If f(x) ∈ [m, M] and a > 0, what is the range of af(x) + b?", "af(x) + b ∈ [am + b, aM + b]"),
  formulaCard("Range transformations", "If f(x) ∈ [m, M] and a < 0, what is the range of af(x) + b?", "af(x) + b ∈ [aM + b, am + b]"),
  formulaCard("Range transformations", "How do you find the range of y = 1/f(x)?", "Take reciprocals of the attained nonzero values of f(x)."),
  formulaCard("Range transformations", "How do you find the range of y = f(x)²?", "First find the range of f(x), then square it."),
  formulaCard("Completing the square", "Complete the square for ax² + bx + c, with a ≠ 0.", "ax² + bx + c = a(x + b/(2a))² + c − b²/(4a)"),
  formulaCard("Completing the square", "What are the ranges of sin x and cos x?", "sin x, cos x ∈ [−1, 1]; sin² x, cos² x ∈ [0, 1]"),
];

export const FLASHCARDS_BY_SUBJECT: Record<Subject, Flashcard[]> = {
  Physics: PHYSICS_FLASHCARDS,
  Chemistry: CHEMISTRY_FLASHCARDS,
  Mathematics: EXISTING_FLASHCARDS_BY_SUBJECT.Mathematics,
  Biology: EXISTING_FLASHCARDS_BY_SUBJECT.Science,
};

export const CHAPTERS_BY_SUBJECT: Record<Subject, ChapterDeck[]> = {
  Physics: [{ name: CHAPTER_BY_SUBJECT.Physics, cards: FLASHCARDS_BY_SUBJECT.Physics }],
  Chemistry: [{ name: CHAPTER_BY_SUBJECT.Chemistry, cards: FLASHCARDS_BY_SUBJECT.Chemistry }],
  Mathematics: [
    { name: CHAPTER_BY_SUBJECT.Mathematics, cards: FLASHCARDS_BY_SUBJECT.Mathematics },
    {
      name: "Trigonometric Functions",
      cards: TRIGONOMETRIC_FUNCTIONS_FLASHCARDS,
      availableFor: {
        className: "Class 11",
        exam: "Joint Entrance Examination (JEE)",
      },
    },
  ],
  Biology: [{ name: CHAPTER_BY_SUBJECT.Biology, cards: FLASHCARDS_BY_SUBJECT.Biology }],
};

export function getChaptersForSelection(
  className: ClassName,
  exam: Exam,
  subject: Subject,
): ChapterDeck[] {
  return CHAPTERS_BY_SUBJECT[subject].filter(
    (chapter) =>
      chapter.availableFor === undefined ||
      (chapter.availableFor.className === className && chapter.availableFor.exam === exam),
  );
}

export function shuffleDeck<T>(cards: T[], random: () => number = Math.random): T[] {
  const shuffled = [...cards];

  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(random() * (index + 1));
    const current = shuffled[index];
    const swapped = shuffled[swapIndex];

    if (current !== undefined && swapped !== undefined) {
      shuffled[index] = swapped;
      shuffled[swapIndex] = current;
    }
  }

  return shuffled;
}