import { describe, expect, it } from "vitest";

import {
  CLASSES,
  getChaptersForSelection,
  EXAM_DETAILS,
  EXAMS,
  FLASHCARDS_BY_SUBJECT,
  SUBJECTS,
  shuffleDeck,
} from "@/data/flashcards";

describe("PREPIXI sample flashcards", () => {
  it("limits study selection to Class 11 and Class 12", () => {
    expect(CLASSES).toEqual(["Class 11", "Class 12"]);
  });

  it("matches each examination to its requested stream and subjects", () => {
    expect(EXAMS).toEqual([
      "Joint Entrance Examination (JEE)",
      "National Eligibility cum Entrance Test (NEET)",
      "State Board Examinations (Boards)",
    ]);
    expect(EXAM_DETAILS[EXAMS[0]].stream).toBe("PCM");
    expect(EXAM_DETAILS[EXAMS[0]].subjects).toEqual(["Physics", "Chemistry", "Mathematics"]);
    expect(EXAM_DETAILS[EXAMS[1]].stream).toBe("PCB");
    expect(EXAM_DETAILS[EXAMS[1]].subjects).toEqual(["Physics", "Chemistry", "Biology"]);
    expect(EXAM_DETAILS[EXAMS[2]].stream).toBe("PCMB");
    expect(EXAM_DETAILS[EXAMS[2]].subjects).toEqual([
      "Physics",
      "Chemistry",
      "Mathematics",
      "Biology",
    ]);
  });

  it("provides ten distinct question and answer cards for each sample chapter", () => {
    for (const subject of SUBJECTS) {
      const cards = FLASHCARDS_BY_SUBJECT[subject];

      expect(cards).toHaveLength(10);
      expect(new Set(cards.map((card) => card.question)).size).toBe(10);
      expect(cards.every((card) => card.answer.length > 0)).toBe(true);
    }
  });

  it("offers the expanded Trigonometric Functions deck only for Class 11 JEE mathematics", () => {
    const class11JeeChapters = getChaptersForSelection(CLASSES[0], EXAMS[0], "Mathematics");
    const trigonometry = class11JeeChapters.find(
      (chapter) => chapter.name === "Trigonometric Functions",
    );

    expect(trigonometry?.cards.length).toBeGreaterThan(10);
    expect(trigonometry?.cards.every((card) => card.question.length > 0 && card.answer.length > 0)).toBe(true);
    const formulaCards = trigonometry?.cards.filter((card) => card.format === "formula") ?? [];
    expect(formulaCards.length).toBeGreaterThan(10);
    expect(formulaCards.every((card) => card.topic && card.answer.includes("=") && !card.answer.includes(";"))).toBe(true);
    expect(new Set(formulaCards.map((card) => card.question)).size).toBe(formulaCards.length);
    expect(
      getChaptersForSelection(CLASSES[1], EXAMS[0], "Mathematics").some(
        (chapter) => chapter.name === "Trigonometric Functions",
      ),
    ).toBe(false);
    expect(
      getChaptersForSelection(CLASSES[0], EXAMS[1], "Mathematics").some(
        (chapter) => chapter.name === "Trigonometric Functions",
      ),
    ).toBe(false);
  });

  it("shuffles a fresh copy of the cards when requested", () => {
    const original = ["first", "second", "third", "fourth"];
    const shuffled = shuffleDeck(original, () => 0);

    expect(shuffled).toEqual(["second", "third", "fourth", "first"]);
    expect(shuffled).not.toBe(original);
    expect(original).toEqual(["first", "second", "third", "fourth"]);
  });
});