import { useEffect, useRef, useState, type MouseEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  Atom,
  BookOpen,
  Calculator,
  Check,
  CircleHelp,
  FlaskConical,
  Leaf,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CHAPTER_BY_SUBJECT,
  getChaptersForSelection,
  CLASSES,
  EXAMS,
  EXAM_DETAILS,
  FLASHCARDS_BY_SUBJECT,
  shuffleDeck,
  type Exam,
  type ChapterDeck,
  type Subject,
} from "@/data/flashcards";
const blackMark = { url: "/assets/prepixi-mark-black.png" };
const whiteMark = { url: "/assets/prepixi-mark-white.png" };

type Screen = "home" | "class" | "exam" | "subject" | "chapter" | "study" | "complete";
type StudyMode = "sequence" | "random";

const SUBJECT_DETAILS: Record<
  Subject,
  { description: string; icon: typeof Atom }
> = {
  Physics: { description: "Units and Measurements", icon: Atom },
  Chemistry: { description: "Structure of Atom", icon: FlaskConical },
  Mathematics: { description: "Quadratic Equations", icon: Calculator },
  Biology: { description: "Life Processes", icon: Leaf },
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PREPIXI CARDS | Study Smarter, Remember Better" },
      {
        name: "description",
        content:
          "Premium flashcards for focused learning. Choose a subject, reveal what you know, and study at your own pace.",
      },
      { property: "og:title", content: "PREPIXI CARDS | Study Smarter, Remember Better" },
      {
        property: "og:description",
        content:
          "Premium flashcards for focused learning. Choose a subject, reveal what you know, and study at your own pace.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [history, setHistory] = useState<Screen[]>(["home"]);
  const [selectedClass, setSelectedClass] = useState<(typeof CLASSES)[number]>("Class 11");
  const [selectedExam, setSelectedExam] = useState<Exam>("Joint Entrance Examination (JEE)");
  const [selectedSubject, setSelectedSubject] = useState<Subject>("Physics");
  const [selectedChapter, setSelectedChapter] = useState(CHAPTER_BY_SUBJECT.Physics);
  const [chapterSelected, setChapterSelected] = useState(false);
  const [studyMode, setStudyMode] = useState<StudyMode>("sequence");
  const [studyCards, setStudyCards] = useState(FLASHCARDS_BY_SUBJECT.Physics);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const pendingTapRef = useRef<{
    side: "left" | "right";
    timeout: number;
  } | null>(null);

  const screen = history[history.length - 1] ?? "home";
  const chapterName = selectedChapter;
  const availableChapters = getChaptersForSelection(selectedClass, selectedExam, selectedSubject);
  const currentCard = studyCards[currentCardIndex] ?? {
    question: "Ready when you are.",
    answer: "Choose a chapter to begin studying.",
  };
  const progressPercent = Math.round(((currentCardIndex + 1) / studyCards.length) * 100);

  useEffect(
    () => () => {
      if (pendingTapRef.current) {
        window.clearTimeout(pendingTapRef.current.timeout);
      }
    },
    [],
  );

  function clearPendingTap() {
    if (pendingTapRef.current) {
      window.clearTimeout(pendingTapRef.current.timeout);
      pendingTapRef.current = null;
    }
  }

  function goTo(nextScreen: Screen) {
    clearPendingTap();
    setHistory((current) => [...current, nextScreen]);
  }

  function goBack() {
    clearPendingTap();
    setHistory((current) => (current.length > 1 ? current.slice(0, -1) : ["home"]));
  }

  function chooseSubject(subject: Subject) {
    const firstChapter = getChaptersForSelection(selectedClass, selectedExam, subject)[0];
    if (!firstChapter) return;

    setSelectedSubject(subject);
    setSelectedChapter(firstChapter.name);
    setChapterSelected(false);
    setStudyMode("sequence");
    setStudyCards([...firstChapter.cards]);
    goTo("chapter");
  }

  function chooseChapter(chapter: ChapterDeck) {
    setSelectedChapter(chapter.name);
    setChapterSelected(true);
    setStudyMode("sequence");
    setStudyCards([...chapter.cards]);
  }

  function chooseMode(mode: StudyMode) {
    const selectedDeck = availableChapters.find((chapter) => chapter.name === selectedChapter);
    if (!selectedDeck) return;

    setStudyMode(mode);
    setStudyCards(mode === "random" ? shuffleDeck(selectedDeck.cards) : [...selectedDeck.cards]);
  }

  function startStudying() {
    setCurrentCardIndex(0);
    setIsFlipped(false);
    goTo("study");
  }

  function moveCard(direction: -1 | 1) {
    clearPendingTap();
    if (direction === 1 && currentCardIndex === studyCards.length - 1) {
      setIsFlipped(false);
      goTo("complete");
      return;
    }

    setCurrentCardIndex((index) => Math.max(0, Math.min(index + direction, studyCards.length - 1)));
    setIsFlipped(false);
  }

  function returnToChapters() {
    clearPendingTap();
    setChapterSelected(false);
    setCurrentCardIndex(0);
    setIsFlipped(false);
    setHistory((current) => (current.length > 2 ? current.slice(0, -2) : ["home"]));
  }

  function handleCardTap(event: MouseEvent<HTMLButtonElement>) {
    if (event.detail === 0) {
      setIsFlipped((flipped) => !flipped);
      return;
    }

    const bounds = event.currentTarget.getBoundingClientRect();
    const side = event.clientX < bounds.left + bounds.width / 2 ? "left" : "right";
    const pendingTap = pendingTapRef.current;

    if (pendingTap?.side === side) {
      clearPendingTap();
      moveCard(side === "right" ? 1 : -1);
      return;
    }

    if (pendingTap) {
      clearPendingTap();
      setIsFlipped((flipped) => !flipped);
    }

    const timeout = window.setTimeout(() => {
      pendingTapRef.current = null;
      setIsFlipped((flipped) => !flipped);
    }, 250);

    pendingTapRef.current = { side, timeout };
  }

  if (screen === "home") {
    return (
      <main className="home-screen">
        <div className="home-container">
          <BrandLogo className="home-brand" />

          <section className="home-copy" aria-labelledby="home-title">
            <h1 id="home-title">
              <span>Study Smarter</span>
              <span className="home-title-muted">Remember Better</span>
            </h1>
            <p>Premium flashcards for focused learning.</p>
          </section>

          <FlashcardArtwork />

          <Button className="home-start-button" size="lg" onClick={() => goTo("class")}>
            <span>Start Studying</span>
            <ArrowRight aria-hidden="true" />
          </Button>

          <p className="home-footer" aria-label="Learn, recall, excel">
            <span />
            <span>Learn · Recall · Excel</span>
            <span />
          </p>
        </div>
      </main>
    );
  }

  if (screen === "study") {
    return (
      <main className="study-screen">
        <div className="study-container">
          <header className="study-header">
            <Button
              aria-label="Back to chapters"
              className="icon-control"
              size="icon"
              variant="ghost"
              onClick={goBack}
            >
              <ArrowLeft aria-hidden="true" />
            </Button>
            <h1>{chapterName}</h1>
            <Button
              aria-label="Open study guide"
              className="icon-control"
              size="icon"
              title="Study guide"
              variant="ghost"
              onClick={() => setHelpOpen(true)}
            >
              <CircleHelp aria-hidden="true" />
            </Button>
          </header>

          <section className="study-progress" aria-label={`Card ${currentCardIndex + 1} of ${studyCards.length}`}>
            <div className="progress-labels">
              <span>Card {String(currentCardIndex + 1).padStart(2, "0")}</span>
              <span>{String(studyCards.length).padStart(2, "0")}</span>
            </div>
            <div
              className="progress-track"
              role="progressbar"
              aria-valuemin={1}
              aria-valuemax={studyCards.length}
              aria-valuenow={currentCardIndex + 1}
            >
              <span className="progress-fill" style={{ width: `${progressPercent}%` }} />
            </div>
          </section>

          <section className="study-workspace" aria-label="Flashcards">
            <Button
              aria-label={isFlipped ? "Show question" : "Show answer"}
              className={`flashcard-button${isFlipped ? " is-flipped" : ""}`}
              variant="ghost"
              onClick={handleCardTap}
            >
              <span className="flashcard-rotator">
                <span className="flashcard-face flashcard-front" aria-hidden={isFlipped}>
                  <span className="card-side-label">QUESTION</span>
                  {currentCard.topic && <span className="card-topic">{currentCard.topic}</span>}
                  <span className="card-copy">{currentCard.question}</span>
                  <span className="card-index">{String(currentCardIndex + 1).padStart(2, "0")}</span>
                </span>
                <span className="flashcard-face flashcard-back" aria-hidden={!isFlipped}>
                  <span className="card-side-label">ANSWER</span>
                  {currentCard.topic && <span className="card-topic">{currentCard.topic}</span>}
                  <span className={`card-copy${currentCard.format === "formula" ? " card-equation" : ""}`}>
                    {currentCard.answer}
                  </span>
                  <span className="card-index">{String(currentCardIndex + 1).padStart(2, "0")}</span>
                </span>
              </span>
            </Button>
            <p className="study-mode-label">
              {studyMode === "random" ? "RANDOM ORDER" : "SEQUENCE WISE"}
            </p>
          </section>

          <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
            <DialogContent className="help-dialog">
              <DialogHeader className="help-heading">
                <span className="help-icon-wrap">
                  <CircleHelp aria-hidden="true" />
                </span>
                <DialogTitle>Study guide</DialogTitle>
                <DialogDescription>Keep your focus on one card at a time.</DialogDescription>
              </DialogHeader>
              <ol className="help-steps">
                <li>
                  <span>01</span>
                  <div>
                    <h2>Reveal the answer</h2>
                    <p>Tap a card once to turn it over. Tap again to return to the question.</p>
                  </div>
                </li>
                <li>
                  <span>02</span>
                  <div>
                    <h2>Move through the deck</h2>
                    <p>Double-tap the right half for the next card, or the left half for the previous card.</p>
                  </div>
                </li>
                <li>
                  <span>03</span>
                  <div>
                    <h2>Return to your chapters</h2>
                    <p>Use the back arrow in the upper-left corner whenever you want to return to chapter selection.</p>
                  </div>
                </li>
              </ol>
            </DialogContent>
          </Dialog>
        </div>
      </main>
    );
  }

  const stepTitle =
    screen === "class"
      ? "Choose Class"
      : screen === "exam"
        ? "Choose Exam"
        : screen === "subject"
          ? "Choose Subject"
          : "Choose Chapter";
  const stepEyebrow =
    screen === "class"
      ? "ACADEMIC LEVEL"
      : screen === "exam"
        ? "TARGET EXAMINATION"
        : screen === "subject"
          ? "SUBJECT STREAM"
          : "CHAPTER SELECTION";
  const stepDescription =
    screen === "class"
      ? "Select your academic standard."
      : screen === "exam"
        ? `Choose your target examination for ${selectedClass}.`
        : screen === "subject"
          ? `${selectedClass} · ${EXAM_DETAILS[selectedExam].stream} stream`
          : `${selectedClass} · ${EXAM_DETAILS[selectedExam].stream} · ${selectedSubject}`;

  if (screen === "complete") {
    return (
      <main className="selection-screen completion-screen">
        <div className="selection-container completion-container">
          <header className="selection-header">
            <Button
              aria-label="Review final flashcard"
              className="icon-control"
              size="icon"
              variant="ghost"
              onClick={goBack}
            >
              <ArrowLeft aria-hidden="true" />
            </Button>
            <BrandLogo className="selection-brand" compact />
            <span aria-hidden="true" />
          </header>

          <section className="completion-card" aria-labelledby="completion-title">
            <span className="completion-mark" aria-hidden="true"><Check /></span>
            <p className="section-eyebrow">STUDY SESSION COMPLETE</p>
            <h1 id="completion-title">Chapter complete</h1>
            <p className="completion-description">
              You finished {chapterName} in {selectedClass}.
            </p>
            <div className="completion-summary">
              <span>{studyCards.length} flashcards reviewed</span>
              <span>{studyMode === "random" ? "Random order" : "Sequence wise"}</span>
            </div>
            <Button className="selection-start-button" size="lg" onClick={returnToChapters}>
              Done
              <ArrowRight aria-hidden="true" />
            </Button>
          </section>
        </div>
      </main>
    );
  }

  return (
    <main className="selection-screen">
      <div className="selection-container">
        <header className="selection-header">
          <Button
            aria-label="Go back"
            className="icon-control"
            size="icon"
            variant="ghost"
            onClick={goBack}
          >
            <ArrowLeft aria-hidden="true" />
          </Button>
          <BrandLogo className="selection-brand" compact />
          <span aria-hidden="true" />
        </header>

        <section className="selection-heading">
          <p className="section-eyebrow">{stepEyebrow}</p>
          <h1>{stepTitle}</h1>
          <p>{stepDescription}</p>
        </section>

        {screen === "class" && (
          <div className="selection-list class-selection-list" aria-label="Choose a class">
            {CLASSES.map((className, index) => (
              <Button
                className="selection-option"
                key={className}
                variant="outline"
                onClick={() => {
                  setSelectedClass(className);
                  goTo("exam");
                }}
              >
                <span className="selection-option-copy">
                  <strong>{className}</strong>
                  <small>{index === 0 ? "Higher Secondary · First year" : "Higher Secondary · Final year"}</small>
                </span>
                <ArrowRight aria-hidden="true" />
              </Button>
            ))}
          </div>
        )}

        {screen === "exam" && (
          <div className="selection-list exam-selection-list" aria-label="Choose an examination">
            {EXAMS.map((exam) => (
              <Button
                className="selection-option exam-option"
                key={exam}
                variant="outline"
                onClick={() => {
                  setSelectedExam(exam);
                  goTo("subject");
                }}
              >
                <span className="selection-option-copy">
                  <strong>{exam}</strong>
                  <small>{EXAM_DETAILS[exam].stream} stream</small>
                </span>
                <span className="stream-tag">{EXAM_DETAILS[exam].stream}</span>
                <ArrowRight aria-hidden="true" />
              </Button>
            ))}
          </div>
        )}

        {screen === "subject" && (
          <div className="selection-list" aria-label="Choose a subject">
            {EXAM_DETAILS[selectedExam].subjects.map((subject) => {
              const Icon = SUBJECT_DETAILS[subject].icon;

              return (
                <Button
                  className="selection-option subject-option"
                  key={subject}
                  variant="outline"
                  onClick={() => chooseSubject(subject)}
                >
                  <span className="subject-icon"><Icon aria-hidden="true" /></span>
                  <span className="subject-copy">
                    <strong>{subject}</strong>
                    <small>{SUBJECT_DETAILS[subject].description}</small>
                  </span>
                  <ArrowRight aria-hidden="true" />
                </Button>
              );
            })}
          </div>
        )}

        {screen === "chapter" && (
          <>
            <div className="selection-list" aria-label="Choose a chapter">
              {availableChapters.map((chapter, index) => {
                const isSelected = chapterSelected && selectedChapter === chapter.name;

                return (
                  <Button
                    aria-pressed={isSelected}
                    className={`chapter-option${isSelected ? " is-selected" : ""}`}
                    key={chapter.name}
                    variant="outline"
                    onClick={() => chooseChapter(chapter)}
                  >
                    <span className="chapter-number">{String(index + 1).padStart(2, "0")}</span>
                    <span className="chapter-copy">
                      <strong>{chapter.name}</strong>
                      <small>{chapter.cards.length} flashcards</small>
                    </span>
                    <span
                      className={`chapter-selection-indicator${isSelected ? " is-selected" : ""}`}
                      aria-hidden="true"
                    >
                      {isSelected && <Check />}
                    </span>
                  </Button>
                );
              })}
            </div>

            <section className="mode-picker" aria-labelledby="mode-title">
              <h2 id="mode-title">Study Mode</h2>
              <div className="mode-options" role="group" aria-label="Study mode">
                <Button
                  aria-pressed={studyMode === "sequence"}
                  className={`mode-option${studyMode === "sequence" ? " is-selected" : ""}`}
                  variant={studyMode === "sequence" ? "default" : "outline"}
                  onClick={() => chooseMode("sequence")}
                >
                  Sequence Wise
                </Button>
                <Button
                  aria-pressed={studyMode === "random"}
                  className={`mode-option${studyMode === "random" ? " is-selected" : ""}`}
                  variant={studyMode === "random" ? "default" : "outline"}
                  onClick={() => chooseMode("random")}
                >
                  Random
                </Button>
              </div>
            </section>

            <Button
              className="selection-start-button"
              disabled={!chapterSelected}
              size="lg"
              onClick={startStudying}
            >
              Start Studying
              <ArrowRight aria-hidden="true" />
            </Button>
          </>
        )}
      </div>
    </main>
  );
}

function BrandLogo({ className = "", compact = false }: { className?: string; compact?: boolean }) {
  return (
    <div className={`brand-logo ${compact ? "brand-logo-compact" : ""} ${className}`}>
      <img src={blackMark.url} alt="" aria-hidden="true" />
      <span className="brand-name">
        <strong>PREPIXI</strong>
        <small>CARDS</small>
      </span>
      <span className="sr-only">PREPIXI CARDS</span>
    </div>
  );
}

function FlashcardArtwork() {
  return (
    <div className="flashcard-artwork" aria-hidden="true">
      <span className="art-halo" />
      <span className="art-rays"><i /><i /><i /></span>
      <span className="art-card art-card-back">
        <img src={whiteMark.url} alt="" />
      </span>
      <span className="art-card art-card-shadow" />
      <span className="art-card art-card-front">
        <strong>?</strong>
        <i />
        <i />
      </span>
    </div>
  );
}