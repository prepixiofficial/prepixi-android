# PREPIXI CARDS — Offline Android APK

This prepared project changes the Lovable-hosted TanStack Start app into a client-side Vite + React SPA and packages the built files with Capacitor. The APK loads files from inside the app; it does not open the Lovable website URL.

## What is included
- Your existing PREPIXI CARDS React/TypeScript UI and static flashcard data.
- The two logo files you uploaded, stored locally under `public/assets/`.
- A Vite client-side entry point and static HTML shell.
- Capacitor configuration (`com.prepixi.cards`, app name `PREPIXI CARDS`).
- `build-apk.yml`, supplied separately, to build a debug APK with GitHub Actions.

## Build using only an Android phone/tablet

### Part A — Create a GitHub repository
1. Open https://github.com in your browser and sign in.
2. Create a new **public or private** repository. A private repository is fine.
3. In the repository, use **Add file → Create new file**.
4. Name the file exactly `.github/workflows/build-apk.yml`.
5. Open the separate `build-apk.yml` file supplied with this package, copy all its contents, paste them into the GitHub editor, and commit the file.

### Part B — Upload the prepared ZIP
1. Rename this archive to exactly `PREPIXI-Android-Offline.zip` if it has a different name.
2. In the repository, choose **Add file → Upload files**.
3. Upload `PREPIXI-Android-Offline.zip` as a single file to the repository root (do not extract it).
4. Commit the upload. This triggers the build workflow.

### Part C — Download the APK
1. Open the repository's **Actions** tab.
2. Select **Build PREPIXI Android APK**.
3. Open the newest run. Wait until it finishes successfully.
4. Open the run's **Artifacts** section.
5. Download `prepixi-cards-debug-apk`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
7. Open `app-debug.apk` on your Android device and allow installation from that source if Android asks.

### If the workflow does not start
- Open **Actions** and enable workflows for the repository if prompted.
- Open the workflow and tap **Run workflow**.
- Check the run log. A red failed step will show the error to fix.

## Offline test
1. Install the APK.
2. Turn on Airplane mode (Wi-Fi and mobile data off).
3. Launch PREPIXI CARDS and test class → exam → subject → chapter → study, flip, previous/next, help, and completion.
4. If a feature fails offline, note the exact screen and error.

## Important limitations
- This APK contains the app's built web files and the local logo images. It does not need Lovable hosting to launch.
- This project brief specifies static flashcard data and no backend. Cloud sync, remote APIs, or externally hosted media (if added later) will still need internet or a local replacement.
- This produces a **debug APK** for direct installation, not a signed Play Store release. A Play Store release needs a signing key and a separate release workflow.
- The Android project is generated during the GitHub Actions run; it is not included as a prebuilt APK.
- The build has not been executed in this environment. If GitHub reports a build error, share the failed log and it can be diagnosed.
